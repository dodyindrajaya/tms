<?php $b=$booking??[]; $item=$item??[]; $v=fn($f,$d='')=>old($f,$b[$f]??$d); $iv=fn($f,$d='')=>old($f,$item[$f]??$d); ?>
<div class="card form-card">
<div class="form-section-title">Booking Information</div>
<div class="form-grid">
<div class="form-group"><label>Customer *</label><select name="customer_id" required><option value="">-- Select Customer --</option><?php foreach($customers as $c): ?><option value="<?=$c['id']?>" <?=$v('customer_id')==$c['id']?'selected':''?>><?=esc($c['name'])?> (<?=esc($c['customer_code'])?>)</option><?php endforeach; ?></select></div>
<div class="form-group"><label>Booking Date *</label><input type="datetime-local" name="booking_date" value="<?=esc(str_replace(' ','T',substr($v('booking_date',date('Y-m-d H:i:s')),0,16)))?>" required></div>
<div class="form-group"><label>Travel Start</label><input type="date" name="travel_start_date" value="<?=esc($v('travel_start_date'))?>"></div>
<div class="form-group"><label>Travel End</label><input type="date" name="travel_end_date" value="<?=esc($v('travel_end_date'))?>"></div>
<div class="form-group"><label>Source *</label><select name="source" required><?php foreach($sources as $k=>$label): ?><option value="<?=$k?>" <?=$v('source','walk_in')===$k?'selected':''?>><?=$label?></option><?php endforeach; ?></select></div>
<div class="form-group"><label>Status *</label><select name="status" required><?php foreach($statuses as $k=>$label): ?><option value="<?=$k?>" <?=$v('status','draft')===$k?'selected':''?>><?=$label?></option><?php endforeach; ?></select></div>
<div class="form-group"><label>Currency *</label><input name="currency_code" value="<?=esc($v('currency_code','IDR'))?>" maxlength="3" required></div>
<div class="form-group"><label>Notes</label><input name="notes" value="<?=esc($v('notes'))?>"></div>
</div>
<div class="form-section-title">First Booking Item <span class="section-hint">MVP supports one line here; additional lines will be added next.</span></div>
<div class="form-grid">
<div class="form-group full"><label>Product *</label><select name="product_id" id="product_id" required><option value="">-- Select Product --</option><?php foreach($products as $p): ?><option value="<?=$p['id']?>" data-price="<?=$p['default_sale_price']?>" <?=$iv('product_id')==$p['id']?'selected':''?>><?=esc($p['name'])?> — <?=esc($p['product_code'])?></option><?php endforeach; ?></select></div>
<div class="form-group"><label>Description</label><input name="description" value="<?=esc($iv('description'))?>"></div>
<div class="form-group"><label>Quantity *</label><input type="number" step="0.01" min="0.01" name="quantity" value="<?=esc($iv('quantity',1))?>" required></div>
<div class="form-group"><label>Unit Sale Price *</label><input type="number" step="0.01" min="0" name="unit_sale_price" id="unit_sale_price" value="<?=esc($iv('unit_sale_price',0))?>" required></div>
<div class="form-group"><label>Discount</label><input type="number" step="0.01" min="0" name="discount_amount" value="<?=esc($iv('discount_amount',0))?>"></div>
<div class="form-group"><label>Tax</label><input type="number" step="0.01" min="0" name="tax_amount" value="<?=esc($iv('tax_amount',0))?>"></div>
</div>
<div class="form-actions"><a class="btn btn-secondary" href="<?=site_url('bookings')?>">Cancel</a><button class="btn btn-primary"><?=!empty($b['id'])?'Save Changes':'Create Booking'?></button></div>
</div>
<script>
document.getElementById('product_id')?.addEventListener('change',function(){let o=this.options[this.selectedIndex];let p=o?.dataset.price;if(p) document.getElementById('unit_sale_price').value=p;});
</script>
