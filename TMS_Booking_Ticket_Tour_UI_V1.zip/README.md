# TMS Booking + Ticketing + Tour UI V1

This package is based directly on the TMS v1 design:
- Booking is the central commercial transaction.
- Ticketing is first-class for flight/train/bus/ferry.
- Tour has packages and departures.
The schema relationships are bookings -> booking_items/ticket_bookings and tour_packages -> tour_departures.

## Included
### Booking
- List/search/filter
- Create/edit/cancel
- Customer selection
- One booking item in MVP form
- Automatic subtotal/total/outstanding calculation
- Product price auto-fill

### Ticketing
- List/search/filter
- Create/edit/cancel
- Flight/train/bus/ferry/other
- Passenger, booking, supplier
- PNR/booking code, ticket number, route, dates/times, class, seat
- Cost/selling price and margin

### Tours
- Tour package list/search
- Create/edit
- Link to Product master
- Departure schedule management
- Capacity/status/meeting point

## Install
1. Copy Models to app/Models/
2. Copy Controllers to app/Controllers/
3. Copy Views subfolders to app/Views/
4. Copy route lines from app/Config/Routes_Booking_Ticket_Tour.php into app/Config/Routes.php
5. Add CSS:
<link rel="stylesheet" href="<?= base_url('css/booking-ticket-tour.css') ?>">

## URLs
http://localhost:8081/bookings
http://localhost:8081/tickets
http://localhost:8081/tours

## Important MVP scope
Booking currently creates one commercial item so we can smoke-test the complete flow quickly. The next refactor should change the booking form to dynamic multiple booking_items and add payment schedules/invoices/payments.

No new database migration is included because these tables already belong to the TMS v1 schema.
