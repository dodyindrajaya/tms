# TMS Customer CRUD UI V1

Refactored Customer CRUD for TMS UI V1.

Copy Controllers/Views into the project and copy the route lines into app/Config/Routes.php.

Expected customer columns: id, customer_code, name, customer_type, phone, email, address, city, province, postal_code, is_active, notes.

If your existing migration uses different column names, adjust Customers.php and _form.php before testing.

The existing CustomerModel should be retained; its allowedFields must include the submitted fields.
