# TMS Booking Detail + Edit V1

Paket ini melanjutkan Booking V1 yang sudah berjalan.

## Tujuan

1. Menambahkan halaman `Booking Detail` read-only.
2. Menambahkan tombol `View` dari daftar Booking.
3. Menambahkan tombol `View Booking` dari halaman Edit.
4. Setelah Create/Update, user diarahkan ke Booking Detail.
5. Menampilkan booking header, customer, item komersial, financial summary dan ticket yang sudah terhubung dengan `booking_id`.
6. Menjaga struktur Booking sebagai parent transaction untuk Ticketing dan proses berikutnya.

## File

- `app/Controllers/Bookings.php`
- `app/Views/bookings/show.php`
- `app/Views/bookings/index.php`
- `app/Views/bookings/edit.php`
- `app/Config/Routes_Booking_Detail_Edit_V1.php`
- `public/css/booking-detail-edit.css`

## Instalasi

### 1. Controller

Backup `app/Controllers/Bookings.php`, lalu replace dengan file dari paket.

### 2. Views

Copy:

```text
app/Views/bookings/show.php
app/Views/bookings/index.php
app/Views/bookings/edit.php
```

### 3. Routes

Tambahkan isi `app/Config/Routes_Booking_Detail_Edit_V1.php` ke `app/Config/Routes.php`.

Minimal route baru:

```php
$routes->get('bookings/show/(:num)', 'Bookings::show/$1');
```

Route edit/update/cancel tetap seperti sebelumnya.

### 4. CSS

Tambahkan:

```php
<link rel="stylesheet" href="<?= base_url('css/booking-detail-edit.css') ?>">
```

ke layout utama jika layout belum otomatis memuat CSS tersebut.

Jika TMS UI V1 Anda mempunyai satu file CSS utama, isi `public/css/booking-detail-edit.css` juga dapat ditempel ke file CSS tersebut.

## Test

1. Buka `/bookings`.
2. Klik `View`.
3. Pastikan Booking Detail tampil.
4. Klik `Edit Booking`.
5. Ubah customer/product/harga/discount/tax.
6. Klik Save Changes.
7. Pastikan kembali ke Booking Detail.
8. Klik Back untuk kembali ke daftar.
9. Pastikan tombol Cancel mengubah status menjadi `cancelled`.

## Catatan

Paket ini tidak mengubah database/migration.

Ticketing yang tampil di Booking Detail hanya membaca record dari:

```text
ticket_bookings.booking_id = bookings.id
```

Belum ada perubahan workflow ticketing dalam paket ini. Itu akan dikerjakan pada Ticketing V1 berikutnya.
