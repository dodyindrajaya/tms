TMS Booking Summary UI V4
Replace:
app/Views/bookings/_form.php
public/css/booking-ticket-tour.css

This version forces the commercial area into:
LEFT  = Product/Pricing inputs
RIGHT = Booking Summary

No database migration or controller change is required.
After replacing files, press Ctrl+F5.
