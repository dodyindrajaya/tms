# TMS Booking Pricing & Tax UI V2

This patch updates the Booking Create/Edit form:

- Quantity, Unit Sale Price, Discount, Tax (%) are stacked vertically on the left.
- Tax is entered as a percentage (example: 10).
- Tax Amount is calculated automatically.
- Total is calculated automatically.
- Discount is applied before tax.
- Server-side calculation is also updated so the database stores the calculated `tax_amount` and `total_amount` consistently.
- Existing database schema is unchanged.

## Install

Copy/overwrite these files into the TMS project:

- `app/Views/bookings/_form.php`
- `app/Controllers/Bookings.php`
- `public/css/booking-ticket-tour.css`

Then run:

```powershell
php spark serve --port 8081
```

## Formula

```text
Gross Subtotal = Quantity × Unit Sale Price
Discounted Base = Gross Subtotal - Discount
Tax Amount = Discounted Base × Tax % / 100
Total = Discounted Base + Tax Amount
```

Example:

```text
Qty          2
Unit Price   1,000,000
Discount     0
Tax          10%

Subtotal     2,000,000
Tax            200,000
Total        2,200,000
```

Note: `bookings.tax_amount` remains an amount in the existing database design. The UI's tax percentage is converted to the amount before saving. No migration is required.
