<?php
$b = $booking ?? [];
$item = $item ?? [];
$v = fn($f, $d = '') => old($f, $b[$f] ?? $d);
$iv = fn($f, $d = '') => old($f, $item[$f] ?? $d);

// Database stores tax_amount as an amount, while the UI accepts tax as a percentage.
$qtyValue      = (float) $iv('quantity', 1);
$unitValue     = (float) $iv('unit_sale_price', 0);
$discountValue = (float) $iv('discount_amount', 0);
$taxAmount     = (float) $iv('tax_amount', 0);
$taxBase       = max(0, ($qtyValue * $unitValue) - $discountValue);
$taxRate       = $taxBase > 0 ? ($taxAmount / $taxBase) * 100 : 0;
$totalValue    = max(0, $taxBase + $taxAmount);
?>

<div class="card form-card">
    <div class="form-section-title">Booking Information</div>

    <div class="form-grid">
        <div class="form-group">
            <label>Customer *</label>
            <select name="customer_id" required>
                <option value="">-- Select Customer --</option>
                <?php foreach ($customers as $c): ?>
                    <option value="<?= $c['id'] ?>" <?= $v('customer_id') == $c['id'] ? 'selected' : '' ?>>
                        <?= esc($c['name']) ?> (<?= esc($c['customer_code']) ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Booking Date *</label>
            <input type="datetime-local" name="booking_date"
                   value="<?= esc(str_replace(' ', 'T', substr($v('booking_date', date('Y-m-d H:i:s')), 0, 16))) ?>"
                   required>
        </div>

        <div class="form-group">
            <label>Travel Start</label>
            <input type="date" name="travel_start_date" value="<?= esc($v('travel_start_date')) ?>">
        </div>

        <div class="form-group">
            <label>Travel End</label>
            <input type="date" name="travel_end_date" value="<?= esc($v('travel_end_date')) ?>">
        </div>

        <div class="form-group">
            <label>Source *</label>
            <select name="source" required>
                <?php foreach ($sources as $k => $label): ?>
                    <option value="<?= $k ?>" <?= $v('source', 'walk_in') === $k ? 'selected' : '' ?>><?= $label ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Status *</label>
            <select name="status" required>
                <?php foreach ($statuses as $k => $label): ?>
                    <option value="<?= $k ?>" <?= $v('status', 'draft') === $k ? 'selected' : '' ?>><?= $label ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Currency *</label>
            <input name="currency_code" value="<?= esc($v('currency_code', 'IDR')) ?>" maxlength="3" required>
        </div>

        <div class="form-group">
            <label>Notes</label>
            <input name="notes" value="<?= esc($v('notes')) ?>">
        </div>
    </div>

    <div class="form-section-title">
        First Booking Item
        <span class="section-hint">MVP supports one line here; additional lines will be added next.</span>
    </div>

    <div class="booking-item-form">
        <div class="form-group">
            <label>Product *</label>
            <select name="product_id" id="product_id" required>
                <option value="">-- Select Product --</option>
                <?php foreach ($products as $p): ?>
                    <option value="<?= $p['id'] ?>"
                            data-price="<?= esc($p['default_sale_price']) ?>"
                            <?= $iv('product_id') == $p['id'] ? 'selected' : '' ?>>
                        <?= esc($p['name']) ?> — <?= esc($p['product_code']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Description</label>
            <input name="description" value="<?= esc($iv('description')) ?>">
        </div>

        <div class="booking-calculation-fields">
            <div class="form-group">
                <label>Quantity *</label>
                <input type="number" step="0.01" min="0.01" name="quantity" id="quantity"
                       value="<?= esc($qtyValue) ?>" required>
            </div>

            <div class="form-group">
                <label>Unit Sale Price *</label>
                <input type="number" step="0.01" min="0" name="unit_sale_price" id="unit_sale_price"
                       value="<?= esc($unitValue) ?>" required>
            </div>

            <div class="form-group">
                <label>Discount</label>
                <input type="number" step="0.01" min="0" name="discount_amount" id="discount_amount"
                       value="<?= esc($discountValue) ?>">
            </div>

            <div class="form-group">
                <label>Tax (%)</label>
                <div class="input-suffix-wrap">
                    <input type="number" step="0.01" min="0" max="100" name="tax_percent" id="tax_percent"
                           value="<?= esc(round($taxRate, 2)) ?>">
                    <span>%</span>
                </div>
                <small class="field-help">Enter the tax percentage, e.g. 10.</small>
            </div>
        </div>

        <div class="booking-summary">
            <div class="summary-row">
                <span>Subtotal</span>
                <strong id="subtotal_display">Rp 0</strong>
            </div>
            <div class="summary-row">
                <span>Discount</span>
                <strong id="discount_display">Rp 0</strong>
            </div>
            <div class="summary-row">
                <span>Tax Amount</span>
                <strong id="tax_amount_display">Rp 0</strong>
            </div>
            <div class="summary-row summary-total">
                <span>TOTAL</span>
                <strong id="total_display">Rp 0</strong>
            </div>
        </div>
    </div>

    <div class="form-actions">
        <a class="btn btn-secondary" href="<?= site_url('bookings') ?>">Cancel</a>
        <button class="btn btn-primary"><?= !empty($b['id']) ? 'Save Changes' : 'Create Booking' ?></button>
    </div>
</div>

<script>
(function () {
    const product = document.getElementById('product_id');
    const quantity = document.getElementById('quantity');
    const unitPrice = document.getElementById('unit_sale_price');
    const discount = document.getElementById('discount_amount');
    const taxPercent = document.getElementById('tax_percent');

    const subtotalDisplay = document.getElementById('subtotal_display');
    const discountDisplay = document.getElementById('discount_display');
    const taxDisplay = document.getElementById('tax_amount_display');
    const totalDisplay = document.getElementById('total_display');

    const formatIDR = (value) => {
        return 'Rp ' + new Intl.NumberFormat('id-ID', {
            maximumFractionDigits: 2
        }).format(value || 0);
    };

    function calculateBooking() {
        const qty = Math.max(0, parseFloat(quantity?.value) || 0);
        const price = Math.max(0, parseFloat(unitPrice?.value) || 0);
        const discountValue = Math.max(0, parseFloat(discount?.value) || 0);
        const taxRate = Math.max(0, Math.min(100, parseFloat(taxPercent?.value) || 0));

        const gross = qty * price;
        const discountApplied = Math.min(discountValue, gross);
        const taxableBase = Math.max(0, gross - discountApplied);
        const taxAmount = taxableBase * taxRate / 100;
        const total = taxableBase + taxAmount;

        if (subtotalDisplay) subtotalDisplay.textContent = formatIDR(gross);
        if (discountDisplay) discountDisplay.textContent = formatIDR(discountApplied);
        if (taxDisplay) taxDisplay.textContent = formatIDR(taxAmount);
        if (totalDisplay) totalDisplay.textContent = formatIDR(total);
    }

    product?.addEventListener('change', function () {
        const option = this.options[this.selectedIndex];
        const price = option?.dataset.price;
        if (price !== undefined && price !== '') {
            unitPrice.value = price;
        }
        calculateBooking();
    });

    [quantity, unitPrice, discount, taxPercent].forEach((el) => {
        el?.addEventListener('input', calculateBooking);
        el?.addEventListener('change', calculateBooking);
    });

    calculateBooking();
})();
</script>
