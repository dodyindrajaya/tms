<?php

namespace App\Models;

use CodeIgniter\Model;

class TourDepartureModel extends Model
{
    protected $table = 'tour_departures';
    protected $primaryKey = 'id';
    $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $protectFields = true;
    protected $allowedFields = [
        'tour_package_id',
        'departure_date',
        'return_date',
        'capacity',
        'status',
        'meeting_point',
        'notes',
        'created_at',
        'updated_at'
    ];

    protected $useTimestamps = true;
    protected $dateFormat = 'datetime';
}
