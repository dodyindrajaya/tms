<?php

namespace App\Models;

use CodeIgniter\Model;

class BookingItemModel extends Model
{
    protected $table = 'booking_items';
    protected $primaryKey = 'id';
    $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $protectFields = true;
    protected $allowedFields = [
        'booking_id',
        'product_id',
        'description',
        'quantity',
        'unit_sale_price',
        'discount_amount',
        'tax_amount',
        'line_total',
        'revenue_account_id',
        'cost_account_id',
        'created_at',
        'updated_at'
    ];

    protected $validationRules = [
        'booking_id' => 'required|is_natural_no_zero',
        'product_id' => 'required|is_natural_no_zero',
        'description' => 'required|max_length[255]'
    ];

    protected $useTimestamps = true;
    protected $dateFormat = 'datetime';
}
