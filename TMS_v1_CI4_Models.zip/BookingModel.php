<?php

namespace App\Models;

use CodeIgniter\Model;

class BookingModel extends Model
{
    protected $table = 'bookings';
    protected $primaryKey = 'id';
    $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $protectFields = true;
    protected $allowedFields = [
        'booking_no',
        'customer_id',
        'booking_date',
        'travel_start_date',
        'travel_end_date',
        'source',
        'status',
        'currency_code',
        'subtotal',
        'discount_amount',
        'tax_amount',
        'total_amount',
        'paid_amount',
        'outstanding_amount',
        'notes',
        'created_by',
        'created_at',
        'updated_at'
    ];

    protected $validationRules = [
        'booking_no' => 'required|max_length[40]',
        'customer_id' => 'required|is_natural_no_zero',
        'booking_date' => 'required'
    ];

    protected $useTimestamps = true;
    protected $dateFormat = 'datetime';
}
