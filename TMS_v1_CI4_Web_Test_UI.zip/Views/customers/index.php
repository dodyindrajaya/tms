<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<h1>Customers</h1>
<p><a class="btn" href="<?= site_url('customers/create') ?>">+ New Customer</a></p>
<table><tr><th>Code</th><th>Name</th><th>Phone</th><th>Email</th><th>Status</th></tr>
<?php foreach($customers as $r): ?><tr>
<td><?= esc($r['customer_code']) ?></td><td><?= esc($r['name']) ?></td><td><?= esc($r['phone']) ?></td><td><?= esc($r['email']) ?></td><td><?= $r['is_active']?'Active':'Inactive' ?></td>
</tr><?php endforeach ?>
</table>
<?= $this->endSection() ?>
