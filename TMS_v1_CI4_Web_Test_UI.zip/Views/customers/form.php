<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<h1>New Customer</h1>
<form method="post" action="<?= site_url('customers/store') ?>">
<label>Customer Code (optional)</label><input name="customer_code">
<label>Name *</label><input name="name" required>
<label>Customer Type</label><select name="customer_type"><option value="individual">Individual</option><option value="company">Company</option></select>
<label>Phone</label><input name="phone">
<label>Email</label><input name="email" type="email">
<label>Address</label><textarea name="address"></textarea>
<button type="submit">Save Customer</button>
</form>
<?= $this->endSection() ?>
