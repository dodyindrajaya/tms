<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<h1>TMS v1 Dashboard</h1>
<div class="grid">
<div class="card"><h3>Customer</h3><a class="btn" href="<?= site_url('customers/create') ?>">New Customer</a></div>
<div class="card"><h3>Booking</h3><a class="btn" href="<?= site_url('bookings/create') ?>">New Booking</a></div>
<div class="card"><h3>Payment</h3><a class="btn" href="<?= site_url('payments/create') ?>">Receive Payment</a></div>
</div>
<div class="card">
<h2>Vertical Slice</h2>
<p>Customer → Booking → Invoice → Payment → Journal → GL → Margin</p>
</div>
<?= $this->endSection() ?>
