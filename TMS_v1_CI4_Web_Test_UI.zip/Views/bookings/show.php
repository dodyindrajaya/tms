<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<h1><?= esc($booking['booking_no']) ?></h1>
<div class="card">
<strong>Customer:</strong> <?= esc($booking['customer_name']) ?><br>
<strong>Status:</strong> <?= esc($booking['status']) ?><br>
<strong>Total:</strong> <?= number_format($booking['total_amount'],2) ?><br>
<strong>Paid:</strong> <?= number_format($booking['paid_amount'],2) ?><br>
<strong>Outstanding:</strong> <?= number_format($booking['outstanding_amount'],2) ?>
</div>
<div class="card"><h2>Items</h2><table><tr><th>Product</th><th>Description</th><th>Qty</th><th>Price</th><th>Total</th></tr>
<?php foreach($items as $i): ?><tr><td><?= esc($i['product_name']) ?></td><td><?= esc($i['description']) ?></td><td><?= $i['quantity'] ?></td><td><?= number_format($i['unit_sale_price'],2) ?></td><td><?= number_format($i['line_total'],2) ?></td></tr><?php endforeach ?>
</table></div>
<?php if($invoice): ?>
<div class="card"><strong>Invoice:</strong> <a href="<?= site_url('invoices/'.$invoice['id']) ?>"><?= esc($invoice['invoice_no']) ?></a></div>
<?php else: ?>
<a class="btn" href="<?= site_url('bookings/'.$booking['id'].'/invoice') ?>">Create Invoice</a>
<?php endif ?>
<?= $this->endSection() ?>
