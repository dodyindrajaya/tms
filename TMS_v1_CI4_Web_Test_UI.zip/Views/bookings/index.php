<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<h1>Bookings</h1><p><a class="btn" href="<?= site_url('bookings/create') ?>">+ New Booking</a></p>
<table><tr><th>Booking</th><th>Customer</th><th>Date</th><th>Status</th><th>Total</th><th>Outstanding</th><th></th></tr>
<?php foreach($bookings as $r): ?><tr>
<td><?= esc($r['booking_no']) ?></td><td><?= esc($r['customer_name']) ?></td><td><?= esc($r['booking_date']) ?></td><td><?= esc($r['status']) ?></td>
<td class="money"><?= number_format($r['total_amount'],2) ?></td><td class="money"><?= number_format($r['outstanding_amount'],2) ?></td>
<td><a class="btn" href="<?= site_url('bookings/'.$r['id']) ?>">Open</a></td>
</tr><?php endforeach ?>
</table>
<?= $this->endSection() ?>
