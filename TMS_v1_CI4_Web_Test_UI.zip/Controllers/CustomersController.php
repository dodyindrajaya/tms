<?php

namespace App\Controllers;

use App\Services\CustomerService;

class CustomersController extends BaseController
{
    public function index()
    {
        $model = new \App\Models\CustomerModel();

        return view('customers/index', [
            'title' => 'Customers',
            'customers' => $model->orderBy('id', 'DESC')->findAll(),
        ]);
    }

    public function create()
    {
        return view('customers/form', ['title' => 'New Customer', 'customer' => null]);
    }

    public function store()
    {
        $service = new CustomerService();

        try {
            $id = $service->create($this->request->getPost());
            return redirect()->to('/customers')->with('success', "Customer #{$id} created.");
        } catch (\Throwable $e) {
            return redirect()->back()->withInput()->with('error', $e->getMessage());
        }
    }
}
