# TMS v1 Web Test UI

Copy:
- Controllers/*.php -> app/Controllers/
- Views/** -> app/Views/
- Routes_TMS_v1.php -> merge its contents into app/Config/Routes.php

Do NOT replace your entire Routes.php if it contains existing routes. Merge the TMS routes.

Test flow:
1. /customers/create
2. Create a customer
3. /bookings/create
4. Create booking
5. Open booking
6. Create invoice
7. Post invoice
8. /payments/create
9. Receive payment
10. /accounting/journal
11. /accounting/gl

This is a development/testing UI, not production UI.
