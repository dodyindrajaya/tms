# TMS v1 — CI4 Migration Foundation

Target: Windows 11 + PHP 8.4.7 + Composer 2.10.2 + MySQL 8.4 on port 3309.

## 1. Copy
Copy the `app/Database/Migrations/2026-08-15-000001_CreateTmsV1Schema.php`
and `app/Database/Seeds/TmsSeeder.php` into your CI4 project.

## 2. Configure `.env`
database.default.hostname = localhost
database.default.database = tms
database.default.username = YOUR_USER
database.default.password = YOUR_PASSWORD
database.default.DBDriver = MySQLi
database.default.port = 3309
database.default.charset = utf8mb4
database.default.DBCollat = utf8mb4_0900_ai_ci

## 3. Run
php spark migrate
php spark db:seed TmsSeeder
php spark migrate:status

## Important
This is the TMS v1 foundation based on the approved XLS design. Accounting is double-entry-ready, with AR/AP, booking costs, invoices, payments, GL lines and report grouping. Before production, we will add business services that enforce balanced journals, posting locks, numbering, tax logic, period closing and automated journals.
