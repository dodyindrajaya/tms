<?php
namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class TmsSeeder extends Seeder
{
    public function run()
    {
        $db = $this->db;

        $db->table('roles')->insertBatch([
            ['name'=>'Administrator','description'=>'Full access'],
            ['name'=>'Sales','description'=>'Customer, quotation and booking'],
            ['name'=>'Finance','description'=>'Finance and accounting'],
        ]);

        $db->table('permissions')->insertBatch([
            ['code'=>'booking.view','name'=>'View booking'],
            ['code'=>'booking.manage','name'=>'Manage booking'],
            ['code'=>'finance.view','name'=>'View finance'],
            ['code'=>'finance.post','name'=>'Post finance'],
            ['code'=>'accounting.view','name'=>'View accounting'],
            ['code'=>'accounting.post','name'=>'Post journal'],
            ['code'=>'whatsapp.send','name'=>'Send WhatsApp'],
        ]);

        $groups = [
            ['code'=>'BS-ASSET','name'=>'Assets','report_type'=>'balance_sheet','sort_order'=>10],
            ['code'=>'BS-LIAB','name'=>'Liabilities','report_type'=>'balance_sheet','sort_order'=>20],
            ['code'=>'BS-EQ','name'=>'Equity','report_type'=>'balance_sheet','sort_order'=>30],
            ['code'=>'PL-REV','name'=>'Revenue','report_type'=>'profit_loss','sort_order'=>40],
            ['code'=>'PL-COGS','name'=>'Cost of Sales','report_type'=>'profit_loss','sort_order'=>50],
            ['code'=>'PL-EXP','name'=>'Operating Expenses','report_type'=>'profit_loss','sort_order'=>60],
        ];
        $db->table('account_groups')->insertBatch($groups);
        $g = [];
        foreach ($db->table('account_groups')->get()->getResult() as $r) $g[$r->code] = $r->id;

        $db->table('accounts')->insertBatch([
            ['code'=>'1100','name'=>'Cash','account_type'=>'asset','account_group_id'=>$g['BS-ASSET'],'is_control_account'=>1,'allow_manual_posting'=>1,'is_active'=>1],
            ['code'=>'1200','name'=>'Bank','account_type'=>'asset','account_group_id'=>$g['BS-ASSET'],'is_control_account'=>1,'allow_manual_posting'=>1,'is_active'=>1],
            ['code'=>'1300','name'=>'Accounts Receivable','account_type'=>'asset','account_group_id'=>$g['BS-ASSET'],'is_control_account'=>1,'allow_manual_posting'=>0,'is_active'=>1],
            ['code'=>'2100','name'=>'Accounts Payable','account_type'=>'liability','account_group_id'=>$g['BS-LIAB'],'is_control_account'=>1,'allow_manual_posting'=>0,'is_active'=>1],
            ['code'=>'3100','name'=>'Owner Equity','account_type'=>'equity','account_group_id'=>$g['BS-EQ'],'is_active'=>1],
            ['code'=>'4100','name'=>'Tour & Travel Revenue','account_type'=>'revenue','account_group_id'=>$g['PL-REV'],'is_active'=>1],
            ['code'=>'4200','name'=>'Ticketing Revenue','account_type'=>'revenue','account_group_id'=>$g['PL-REV'],'is_active'=>1],
            ['code'=>'5100','name'=>'Travel Cost of Sales','account_type'=>'cogs','account_group_id'=>$g['PL-COGS'],'is_active'=>1],
            ['code'=>'6100','name'=>'Operating Expenses','account_type'=>'expense','account_group_id'=>$g['PL-EXP'],'is_active'=>1],
        ]);

        $db->table('fiscal_years')->insert([
            'year'=>(int)date('Y'),'start_date'=>date('Y-01-01'),'end_date'=>date('Y-12-31'),'status'=>'open'
        ]);

        $db->table('journals')->insertBatch([
            ['code'=>'SALES','name'=>'Sales Journal','journal_type'=>'sales','is_active'=>1],
            ['code'=>'PURCHASE','name'=>'Purchase Journal','journal_type'=>'purchase','is_active'=>1],
            ['code'=>'CASH','name'=>'Cash Journal','journal_type'=>'cash','is_active'=>1],
            ['code'=>'BANK','name'=>'Bank Journal','journal_type'=>'bank','is_active'=>1],
            ['code'=>'GENERAL','name'=>'General Journal','journal_type'=>'general','is_active'=>1],
        ]);

        $cash = $db->table('accounts')->where('code','1100')->get()->getRow();
        $db->table('payment_methods')->insert([
            'code'=>'CASH','name'=>'Cash','method_type'=>'cash',
            'clearing_account_id'=>$cash->id,'is_active'=>1
        ]);
    }
}
