# TMS UI V1

UI foundation for CodeIgniter 4 TMS.

## Included

- Master layout
- Sidebar navigation
- Topbar
- Responsive/mobile sidebar
- Page header component
- Stat card component
- Search/filter component
- Status badge component
- Empty state component
- Modal component
- Flash notification
- Modern business dashboard styling
- Responsive tables/forms
- Small vanilla JS helper

## Installation

Copy:

- `app/Views/layouts/*` -> `app/Views/layouts/`
- `app/Views/components/*` -> `app/Views/components/`
- `public/css/tms.css` -> `public/css/tms.css`
- `public/js/tms.js` -> `public/js/tms.js`

If those folders already contain files, merge carefully rather than blindly overwriting.

## Usage

A normal page can use:

```php
<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>

<?= view('components/page_header', [
    'eyebrow' => 'Master Data',
    'title' => 'Customers',
    'subtitle' => 'Manage your travel customers',
    'action' => [
        'label' => 'New Customer',
        'url' => site_url('customers/create')
    ]
]) ?>

<?= $this->endSection() ?>
```

The layout automatically provides sidebar, topbar, flash messages, footer, CSS and JS.

## Important

The sidebar contains planned TMS routes. Routes that have not been implemented yet will naturally return a 404 until their controllers/routes exist.

The UI is intentionally dependency-light: CodeIgniter View + CSS + vanilla JavaScript.
