# TMS Product CRUD UI V1

This package follows the TMS_v1 database design for `products`.

Products fields:
- id
- product_code
- name
- category
- unit
- default_sale_price
- default_cost_price
- revenue_account_id
- cost_account_id
- is_active
- created_at
- updated_at

Categories follow the design:
tour, flight, train, bus, hotel, transport, rental, guide, other.

## Install

1. Copy `app/Models/ProductModel.php` to `app/Models/`.
2. Copy `app/Controllers/Products.php` to `app/Controllers/`.
3. Copy `app/Views/products/` to `app/Views/products/`.
4. Copy the route lines from `app/Config/Routes_Products.php` into `app/Config/Routes.php`.
5. Copy `public/css/product-crud.css` to `public/css/`.
6. In `app/Views/layouts/main.php`, after tms.css, add:

<link rel="stylesheet" href="<?= base_url('css/product-crud.css') ?>">

If your main layout already loads a global CRUD helper CSS with these classes, the extra CSS may not be necessary.

## Routes

GET  /products
GET  /products/create
POST /products/store
GET  /products/edit/{id}
POST /products/update/{id}
POST /products/delete/{id}

## Test

php spark serve

Then open:
http://localhost:8081/products

Test:
- Create
- Edit
- Update
- Search
- Category filter
- Status filter
- Delete
- Pagination

Important:
The `ProductModel` in this package uses `protected $useAutoIncrement = true;`.
This is intentional because an unqualified `$useAutoIncrement` inside the class causes the same PHP ParseError that occurred previously in CustomerModel.
