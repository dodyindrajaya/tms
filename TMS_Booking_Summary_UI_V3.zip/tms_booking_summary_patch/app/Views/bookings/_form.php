<?php $b=$booking??[]; $item=$item??[]; $v=fn($f,$d='')=>old($f,$b[$f]??$d); $iv=fn($f,$d='')=>old($f,$item[$f]??$d); ?>
<div class="card form-card">
<div class="form-section-title">Booking Information</div>
<div class="form-grid">
<div class="form-group"><label>Customer *</label><select name="customer_id" required><option value="">-- Select Customer --</option><?php foreach($customers as $c): ?><option value="<?=$c['id']?>" <?=$v('customer_id')==$c['id']?'selected':''?>><?=esc($c['name'])?> (<?=esc($c['customer_code'])?>)</option><?php endforeach; ?></select></div>
<div class="form-group"><label>Booking Date *</label><input type="datetime-local" name="booking_date" value="<?=esc(str_replace(' ','T',substr($v('booking_date',date('Y-m-d H:i:s')),0,16)))?>" required></div>
<div class="form-group"><label>Travel Start</label><input type="date" name="travel_start_date" value="<?=esc($v('travel_start_date'))?>"></div>
<div class="form-group"><label>Travel End</label><input type="date" name="travel_end_date" value="<?=esc($v('travel_end_date'))?>"></div>
<div class="form-group"><label>Source *</label><select name="source" required><?php foreach($sources as $k=>$label): ?><option value="<?=$k?>" <?=$v('source','walk_in')===$k?'selected':''?>><?=$label?></option><?php endforeach; ?></select></div>
<div class="form-group"><label>Status *</label><select name="status" required><?php foreach($statuses as $k=>$label): ?><option value="<?=$k?>" <?=$v('status','draft')===$k?'selected':''?>><?=$label?></option><?php endforeach; ?></select></div>
<div class="form-group"><label>Currency *</label><input name="currency_code" value="<?=esc($v('currency_code','IDR'))?>" maxlength="3" required></div>
<div class="form-group"><label>Notes</label><input name="notes" value="<?=esc($v('notes'))?>"></div>
</div>
<div class="form-section-title">First Booking Item <span class="section-hint">MVP supports one line here; additional lines will be added next.</span></div>
<div class="booking-commercial-grid">
    <div class="booking-item-form">
        <div class="form-group">
            <label>Product *</label>
            <select name="product_id" id="product_id" required>
                <option value="">-- Select Product --</option>
                <?php foreach($products as $p): ?>
                    <option value="<?=$p['id']?>" data-price="<?=$p['default_sale_price']?>" <?=$iv('product_id')==$p['id']?'selected':''?>><?=esc($p['name'])?> — <?=esc($p['product_code'])?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Description</label>
            <input name="description" value="<?=esc($iv('description'))?>">
        </div>

        <?php
            $initialQty = (float)$iv('quantity', 1);
            $initialUnit = (float)$iv('unit_sale_price', 0);
            $initialDiscount = (float)$iv('discount_amount', 0);
            $initialTaxAmount = (float)$iv('tax_amount', 0);
            $initialTaxBase = max(0, ($initialQty * $initialUnit) - $initialDiscount);
            $initialTaxPercent = $initialTaxBase > 0 ? round(($initialTaxAmount / $initialTaxBase) * 100, 4) : 0;
        ?>

        <div class="booking-calculation-fields">
            <div class="form-group">
                <label>Quantity *</label>
                <input type="number" step="0.01" min="0.01" name="quantity" id="quantity" value="<?=esc($initialQty)?>" required>
            </div>

            <div class="form-group">
                <label>Unit Sale Price *</label>
                <input type="number" step="0.01" min="0" name="unit_sale_price" id="unit_sale_price" value="<?=esc($initialUnit)?>" required>
            </div>

            <div class="form-group">
                <label>Discount</label>
                <input type="number" step="0.01" min="0" name="discount_amount" id="discount_amount" value="<?=esc($initialDiscount)?>">
            </div>

            <div class="form-group">
                <label>Tax (%)</label>
                <div class="input-suffix-wrap tax-input-wrap">
                    <input type="number" step="0.01" min="0" max="100" name="tax_percent" id="tax_percent" value="<?=esc($initialTaxPercent)?>">
                    <span>%</span>
                </div>
                <small class="field-help">Enter the tax percentage, e.g. 10.</small>
            </div>
        </div>
    </div>

    <div class="booking-summary-card">
        <div class="booking-summary-title">BOOKING SUMMARY</div>
        <table class="booking-summary-table">
            <tbody>
                <tr>
                    <td>Subtotal</td>
                    <td id="summary_subtotal">Rp 0</td>
                </tr>
                <tr>
                    <td>Discount</td>
                    <td id="summary_discount">Rp 0</td>
                </tr>
                <tr>
                    <td>Tax</td>
                    <td id="summary_tax_percent">0%</td>
                </tr>
                <tr>
                    <td>Tax Amount</td>
                    <td id="summary_tax_amount">Rp 0</td>
                </tr>
            </tbody>
            <tfoot>
                <tr>
                    <th>TOTAL</th>
                    <th id="summary_total">Rp 0</th>
                </tr>
            </tfoot>
        </table>
    </div>
</div>
<div class="form-actions"><a class="btn btn-secondary" href="<?=site_url('bookings')?>">Cancel</a><button class="btn btn-primary"><?=!empty($b['id'])?'Save Changes':'Create Booking'?></button></div>
</div>
<script>
(function () {
    const product = document.getElementById('product_id');
    const qty = document.getElementById('quantity');
    const unit = document.getElementById('unit_sale_price');
    const discount = document.getElementById('discount_amount');
    const taxPercent = document.getElementById('tax_percent');

    const subtotalEl = document.getElementById('summary_subtotal');
    const discountEl = document.getElementById('summary_discount');
    const taxPercentEl = document.getElementById('summary_tax_percent');
    const taxAmountEl = document.getElementById('summary_tax_amount');
    const totalEl = document.getElementById('summary_total');

    const money = value => 'Rp ' + new Intl.NumberFormat('id-ID', {
        maximumFractionDigits: 2,
        minimumFractionDigits: 0
    }).format(value || 0);

    function calculate() {
        const q = parseFloat(qty?.value) || 0;
        const u = parseFloat(unit?.value) || 0;
        const d = Math.max(0, parseFloat(discount?.value) || 0);
        const t = Math.max(0, Math.min(100, parseFloat(taxPercent?.value) || 0));

        const grossSubtotal = Math.max(0, q * u);
        const appliedDiscount = Math.min(d, grossSubtotal);
        const taxableBase = Math.max(0, grossSubtotal - appliedDiscount);
        const taxAmount = Math.round((taxableBase * t / 100) * 100) / 100;
        const total = Math.round((taxableBase + taxAmount) * 100) / 100;

        subtotalEl.textContent = money(grossSubtotal);
        discountEl.textContent = appliedDiscount > 0 ? '- ' + money(appliedDiscount) : money(0);
        taxPercentEl.textContent = t + '%';
        taxAmountEl.textContent = money(taxAmount);
        totalEl.textContent = money(total);
    }

    product?.addEventListener('change', function () {
        const option = this.options[this.selectedIndex];
        const price = option?.dataset.price;
        if (price && (!unit.value || parseFloat(unit.value) === 0)) {
            unit.value = price;
        }
        calculate();
    });

    [qty, unit, discount, taxPercent].forEach(el => {
        el?.addEventListener('input', calculate);
        el?.addEventListener('change', calculate);
    });

    calculate();
})();
</script>
