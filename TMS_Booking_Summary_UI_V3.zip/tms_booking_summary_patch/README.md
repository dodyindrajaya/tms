# TMS Booking Summary UI V3

Patch untuk memperbaiki tampilan form Create/Edit Booking.

## Perubahan

- Quantity, Unit Sale Price, Discount, dan Tax (%) tetap tersusun vertikal di sisi kiri.
- Subtotal, Discount, Tax %, Tax Amount, dan TOTAL dipindahkan ke sisi kanan.
- Ringkasan dibuat dalam tabel yang lebih rapi.
- TOTAL dibuat lebih menonjol.
- Perhitungan tetap otomatis saat Qty, Price, Discount, atau Tax berubah.
- Responsive: pada layar kecil summary turun ke bawah form.
- Tidak membutuhkan migration database.

## File

Copy/overwrite:

- `app/Views/bookings/_form.php`
- `public/css/booking-ticket-tour.css`

Patch ini tidak mengubah Controller karena perhitungan server-side dari Booking Pricing/Tax V2 tetap digunakan.

## Rumus

Gross Subtotal = Quantity x Unit Sale Price
Discounted Base = Gross Subtotal - Discount
Tax Amount = Discounted Base x Tax % / 100
Total = Discounted Base + Tax Amount
